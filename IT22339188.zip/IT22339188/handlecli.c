#include "srvfun.h"

void handle_client(int connfd, struct sockaddr_in cli_addr) {
    char cli_ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(cli_addr.sin_addr), cli_ip, INET_ADDRSTRLEN);
    int cli_port = ntohs(cli_addr.sin_port);
    char requested_file[256];
    char buffer[BUFFER_SIZE];

    // Send list of files
    send_file_list(connfd);

    // Receive requested file
    int bytes_received = recv(connfd, buffer, sizeof(buffer), 0);
    if (bytes_received <= 0) {
        fprintf(stderr,"Failed to receive requested file");
        close(connfd);
        return;
    }
    buffer[bytes_received] = '\0';  // Null-terminate the received file name

    // Send the requested file
    log_client_info(cli_ip, cli_port, buffer, "Requested");
    send_requested_file(connfd, buffer);
    log_client_info(cli_ip, cli_port, buffer, "Success");
    close(connfd);
}


