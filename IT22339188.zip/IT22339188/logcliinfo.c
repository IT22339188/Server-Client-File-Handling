#include "srvfun.h"

#define LOG_FILE "log_srv9188.txt"

void log_client_info(const char *cliaddr, int CLI_TCP_PORT, const char *requested_file, const char *status)
{
   FILE *log_file = fopen(LOG_FILE, "a");
     if(log_file == NULL)
     {
        fprintf(stderr, "Could not open log file");
        return;
     }

  time_t t = time(NULL);
  struct tm tm = *localtime(&t);

  fprintf(log_file, "Client %s:%d | Date: %d-%02d-%02d %02d:%02d:%02d | File: %s | Status: %s\n", cliaddr, CLI_TCP_PORT, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec, requested_file, status);
  
  fclose(log_file);
}
 
