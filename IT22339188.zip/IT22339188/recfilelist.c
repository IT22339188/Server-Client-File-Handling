#include "clifun.h"

void receive_file_list(int connfd, char file_list[MAX_FILES][256], int *file_count) {
    char buffer[BUFFER_SIZE];
    int bytes_received = recv(connfd, buffer, sizeof(buffer), 0);

    if (bytes_received <= 0) {
        fprintf(stderr, "Failed to receive file list\n");
        close(connfd);
        exit(1);
    }

    buffer[bytes_received] = '\0'; // Null-terminate the string

    printf("Available files:\n");

    // Parse the file names and print them in the desired format
    char *file_name = strtok(buffer, "\n");
    *file_count = 0;

    while (file_name != NULL && *file_count < MAX_FILES) {
        printf("%d. %s\n", *file_count + 1, file_name);
        strncpy(file_list[*file_count], file_name, sizeof(file_list[*file_count]) - 1);
        file_list[*file_count][sizeof(file_list[*file_count]) - 1] = '\0'; // Null-terminate
        file_name = strtok(NULL, "\n");
        (*file_count)++;
    }
}

