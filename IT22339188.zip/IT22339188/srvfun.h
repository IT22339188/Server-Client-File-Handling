#ifndef SRVFUN_H
#define SRVFUN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <time.h>
#include<signal.h>

#define SA struct sockaddr
#define	LISTENQ	1024
#define SERV_TCP_PORT 2233
#define BUFFER_SIZE 1024
#define SHARED_DIR "sharedfiles/"

void log_client_info(const char *cliaddr, int CLI_TCP_PORT, const char *requested_file, const char *status);
void send_file_list(int connfd);
void send_requested_file(int connfd, const char *file_name);
void handle_client(int connfd, struct sockaddr_in cliaddr);

#endif
