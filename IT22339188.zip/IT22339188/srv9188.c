#include "srvfun.h"
#define LOG_FILE "log_srv9188.txt"

int main() {
  int listenfd,connfd;
  struct sockaddr_in servaddr, cliaddr;
  socklen_t len;
  void sig_child(int);
  
  if ( (listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
     {
		fprintf(stderr, "socket creation failed\n");
		exit (1);
     }
     
        bzero(&servaddr, sizeof(servaddr));
        
	servaddr.sin_family      = AF_INET;
	servaddr.sin_addr.s_addr = INADDR_ANY;
	servaddr.sin_port        = htons(SERV_TCP_PORT); /* svr9188 */

	if ( (bind(listenfd, (SA *) &servaddr, sizeof(servaddr))) < 0) {
		fprintf(stderr, "bind failed\n");
		exit (1);
	}
		

	if ( listen(listenfd, LISTENQ) < 0) {
		fprintf(stderr, "listen failed\n");
		exit (1);
	}
	
	//handle Zombie process
	signal(SIGCHLD,sig_child);
	
	printf("Server listening on port %d\n", SERV_TCP_PORT);

	for ( ; ; ) {
		len = sizeof(cliaddr);
		connfd = accept(listenfd, (struct sockaddr *)&cliaddr, &len);
                if (connfd < 0) {
                    fprintf(stderr,"Failed to accept connection");
                    continue;
                }

                if (fork() == 0) // Child process to handle client
                { 
                   close(listenfd);
                   handle_client(connfd, cliaddr);
                   exit(0);
                } 
                else 
                   close(connfd); // Parent process closes the socket
                
	}
	
	close(listenfd);
	return 0;
}




        
