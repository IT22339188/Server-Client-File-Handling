#include "clifun.h"

void receive_file(int connfd, int file_index, char file_list[MAX_FILES][256]) {
    char buffer[BUFFER_SIZE];
    int bytes_received = 0, total_bytes_received = 0;
    long file_size = 0;
    int expected_progress = 1;  // Start tracking progress from 1%

    // Get the original file name from the file list
    char *file_name = file_list[file_index];
    // Open file in binary mode ("wb"), using the original file name
    FILE *file_fd = fopen(file_name, "wb");
    if (file_fd == NULL) {
        fprintf(stderr, "Failed to create file: %s\n", file_name);
        close(connfd);
        exit(1);
    }

    // First, receive the file size from the server
    if (recv(connfd, &file_size, sizeof(file_size), 0) <= 0) {
        fprintf(stderr, "Failed to receive file size\n");
        fclose(file_fd);
        exit(1);
    }
    
    if (file_size <= 0) {
        fprintf(stderr, "Invalid file size received\n");
        fclose(file_fd);
        exit(1);
    }

    printf("Downloading %s (%ld bytes)...\n", file_name, file_size);

    // Receive file data in chunks
    while ((bytes_received = recv(connfd, buffer, sizeof(buffer), 0)) > 0) {
        fwrite(buffer, 1, bytes_received, file_fd);
        total_bytes_received += bytes_received;

        // Calculate the current progress percentage
        int current_progress = (total_bytes_received * 100) / file_size;

        // Print every percentage one by one
        while (expected_progress <= current_progress && expected_progress <= 100) {
            printf("Progress: %d%%\n", expected_progress);
            expected_progress++;
        }

        // Break if the entire file is received
        if (total_bytes_received >= file_size) {
            break;
        }
    }

    // Check if the download is complete
    if (total_bytes_received == file_size) {
        printf("Download complete. File saved as %s\n", file_name);
    } else {
        fprintf(stderr, "Error: Download incomplete, expected %ld bytes, but received %d bytes\n", file_size, total_bytes_received);
    }

    fclose(file_fd);
}

