#include <sys/wait.h>
#include <sys/wait.h>

void sig_child(int signo)
{
   pid_t pid;
   int s;
   
   while((pid ==waitpid(-1,&s,WNOHANG))>0)
   
   return;
}



