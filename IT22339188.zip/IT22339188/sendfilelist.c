#include "srvfun.h"


void send_file_list(int connfd)
{
    DIR *d = opendir(SHARED_DIR);
    if (!d)
    {
       fprintf(stderr, "Unable to open shared directory/n");
       return;
    }
    
    struct dirent *dir;
    char file_list[BUFFER_SIZE] = "";
    
    while ((dir = readdir(d))!= NULL) {
        if(dir->d_type == DT_REG){
           strcat(file_list,dir->d_name);
           strcat(file_list,"\n");
        }
    }
    
    closedir(d);
    
    
    // Send the file list
    if (send(connfd, file_list, strlen(file_list), 0) < 0) 
    {
        fprintf(stderr, "Failed to send file list");
    }
}
