#include "srvfun.h"

void send_requested_file(int connfd, const char* file_name) {
    char buffer[BUFFER_SIZE];
    int bytes_read, bytes_sent;
    FILE *file_fd = fopen(file_name, "rb");
    
    if (file_fd == NULL) {
        fprintf(stderr, "Failed to open file: %s\n", file_name);
        close(connfd);
        return;
    }
    
    // Get the total file size for progress calculation
    fseek(file_fd, 0L, SEEK_END);
    long file_size = ftell(file_fd);
    rewind(file_fd);

    // Send the file size to the client
    send(connfd, &file_size, sizeof(file_size), 0);

    printf("Sending %s to client...\n", file_name);
    
    // Send the file in chunks
    while ((bytes_read = fread(buffer, 1, sizeof(buffer), file_fd)) > 0) {
        bytes_sent = send(connfd, buffer, bytes_read, 0);
        if (bytes_sent < 0) {
            fprintf(stderr, "Failed to send data\n");
            break;
        }
    }

    fclose(file_fd);
    printf("File transfer complete for %s\n", file_name);
}
