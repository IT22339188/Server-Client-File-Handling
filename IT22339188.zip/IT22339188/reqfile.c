#include "clifun.h"


void request_file(int connfd, char file_list[MAX_FILES][256], int file_count) {

    int file_index;

    printf("Enter the file no to download (1 to %d): ", file_count);

    scanf("%d", &file_index);


    if (file_index < 1 || file_index > file_count) {

        printf("Invalid index. Please try again.\n");

        return;

    }


    // Send the selected file name to the server

    send(connfd, file_list[file_index - 1], strlen(file_list[file_index - 1]), 0);

}
