#include "clifun.h"

int connect_to_server() {
    int connfd;
    struct sockaddr_in servaddr;

    connfd = socket(AF_INET, SOCK_STREAM, 0);
    if (connfd < 0) {
        fprintf(stderr, "Socket creation failed\n");
        exit(1);
    }

    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(SERV_TCP_PORT);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (connect(connfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        fprintf(stderr, "Connection to server failed\n");
        close(connfd);
        exit(1);
    }

    return connfd;
}

