#ifndef CLIFUN_H
#define CLIFUN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <unistd.h> 

#define SA struct sockaddr
#define BUFFER_SIZE 1024
#define SERV_TCP_PORT 2233
#define CLI_TCP_PORT 9188
#define	LISTENQ	1024
#define MAX_FILES 50

int connect_to_server();
void receive_file_list(int connfd, char file_list[MAX_FILES][256], int *file_count);
void request_file(int connfd, char file_list[MAX_FILES][256], int file_count);
void receive_file(int connfd, int file_index, char file_list[MAX_FILES][256]);


#endif
