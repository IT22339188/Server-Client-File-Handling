#include "clifun.h"

int main() {
    int connfd = connect_to_server();
    
    char file_list[MAX_FILES][256];
    int file_count = 0;
    int file_index;

    receive_file_list(connfd, file_list, &file_count);
    request_file(connfd, file_list, file_count);
    receive_file(connfd, file_index, file_list);

    close(connfd);
    return 0;
}
